#!/usr/bin/env python3
"""Generate release artifacts after a *successful* .NET build."""
import argparse, json, shutil, zipfile
from pathlib import Path
from datetime import datetime,timezone

p=argparse.ArgumentParser()
p.add_argument('output', type=Path,help='Oracle build output containing LogMimic.dll')
p.add_argument('--repository',required=True,help='OWNER/REPOSITORY')
p.add_argument('--version',required=True,help='four-part version')
p.add_argument('--tag',required=True)
p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
a=p.parse_args()
out=a.output.resolve()
root=a.root.resolve()
assert (out/'LogMimic.dll').is_file(),f'Build failed to produce {out}/LogMimic.dll'
assert (out/'MirageUI.dll').is_file(),f'Missing required {out}/MirageUI.dll'
manifest_file=out/'LogMimic.json'
assert manifest_file.is_file(),f'Missing required {manifest_file}'
manifest=json.loads(manifest_file.read_text(encoding='utf-8'))
assert manifest['InternalName']=='LogMimic'
manifest['AssemblyVersion']=a.version
manifest['RepoUrl']=f'https://github.com/{a.repository}'
manifest['IconUrl']=f'https://raw.githubusercontent.com/{a.repository}/main/plugins/LogMimic/icon.png'
manifest['DownloadLinkInstall']=f'https://github.com/{a.repository}/releases/download/{a.tag}/latest.zip'
manifest['DownloadLinkUpdate']=manifest['DownloadLinkInstall']
manifest['LastUpdate']=int(datetime.now(timezone.utc).timestamp())
# Multi-plugin repository: retain all OTHER plugin entries on every LogMimic release.
index_path = root / 'pluginmaster.json'
previous = json.loads(index_path.read_text(encoding='utf-8')) if index_path.exists() else []
if not isinstance(previous, list):
    raise RuntimeError('pluginmaster.json must be a JSON array')
next_manifest = [p for p in previous if isinstance(p, dict) and p.get('InternalName') != 'LogMimic']
next_manifest.append(manifest)
index_path.write_text(json.dumps(next_manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(root/'dist').mkdir(exist_ok=True)
# Output from upstream Oracle build: includes the necessary MirageUI.dll and data.
with zipfile.ZipFile(root/'dist'/'latest.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for file in sorted(out.rglob('*')):
        if not file.is_file(): continue
        if file.resolve().is_relative_to(root/'dist') or file.resolve()==(root/'pluginmaster.json').resolve(): continue
        rel=file.relative_to(out)
        if any(seg in {'ref','refint'} for seg in rel.parts): continue
        if file.suffix.lower() in ('.pdb','.xml'): continue
        if file.name in ('Oracle.json','Oracle.dll'): continue
        z.write(file,str(rel).replace('\\','/'))
print('Release:',root/'dist'/'latest.zip')
print('Manifest:',root/'pluginmaster.json')
