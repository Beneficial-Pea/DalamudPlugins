import ast
import subprocess
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

patcher = Path(__file__).resolve().parents[1] / 'patch_oracle.py'
tree = ast.parse(patcher.read_text())
plans = []
for node in tree.body:
    if not isinstance(node, ast.Expr) or not isinstance(node.value, ast.Call): continue
    call = node.value
    if not isinstance(call.func, ast.Name) or call.func.id != 'patch': continue
    file = ast.literal_eval(call.args[0])
    items = ast.literal_eval(call.args[1]); plans.append((file,items))
with TemporaryDirectory() as tmp:
    root = Path(tmp)
    for filename, plan in plans:
        target=root / filename
        target.parent.mkdir(parents=True, exist_ok=True)
        if filename.endswith('Plugin.cs'):
            # add required directory and duplicate anchors as expected
            pass
        target.write_text('\n__SPLIT__\n'.join(x[0] for x in plan for _ in range(x[2] if len(x) == 3 else 1)))
    p=subprocess.run([sys.executable,str(patcher),str(root)], capture_output=True,text=True)
    assert p.returncode == 0,(p.stdout,p.stderr)
    assert (root/'Oracle/Services/LogMimicService.cs').is_file()
    assert (root/'Oracle/Services/LogMimicStatusWindow.cs').is_file()
    for filename, plan in plans:
        t=(root / filename).read_text()
        for x in plan:
            assert x[1] in t, (filename,x[1][:50])
print(f'PASS: all {len(plans)} source-file patches applied to synthetic upstream fixture')
