#!/usr/bin/env python3
"""Patch the upstream exatrines/Oracle v1.3.4 checkout in place.
Creates .before_replay backups, verifies every anchor and fails closed on changed upstream code.
"""
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit("Usage: python patch_oracle.py <path-to-Oracle-repo>")
root = Path(sys.argv[1]).resolve()
source = Path(__file__).resolve().parent
if not (root / "Oracle" / "Plugin.cs").is_file():
    raise SystemExit("Cannot find Oracle/Plugin.cs. Supply the upstream repository root.")

def patch(name, replacements):
    path = root / name
    data = path.read_text(encoding="utf-8-sig")
    for item in replacements:
        before, after = item[:2]
        expected = item[2] if len(item) == 3 else 1
        n = data.count(before)
        if n != expected:
            raise SystemExit(f"STOP: {name}: expected {expected} matching anchor(s), got {n}: {before[:90]!r}")
        data = data.replace(before, after, expected)
    backup = path.with_suffix(path.suffix + ".before_replay")
    if not backup.exists(): backup.write_text(path.read_text(encoding="utf-8-sig"), encoding="utf-8")
    path.write_text(data, encoding="utf-8")
    print("PATCHED", name)

patch("Oracle/Models/TimelineModels.cs", [
    ('    public List<TimelineCue> Cues { get; set; } = [];',
     '''    public List<TimelineCue> Cues { get; set; } = [];

    // FFLogs faithful playback. Disabled for every existing Oracle timeline.
    public bool ReplayEnabled { get; set; }
    public List<uint> ReplayExcludedActionIds { get; set; } = [];
    public List<uint> ReplayIndependentActionIds { get; set; } = [];
'''),
    ('    public uint ActionId { get; set; }\n\n    /// <summary>\n    /// Memo text.',
     '''    public uint ActionId { get; set; }

    // Report-local actor id is NOT the live in-game GameObjectId.
    public int ReplayTargetLogId { get; set; }
    public string ReplayTargetName { get; set; } = string.Empty;
    // default, self, ally, enemy, unknown
    public string ReplayTargetKind { get; set; } = "default";

    /// <summary>
    /// Memo text.'''),
    ('            Effected = IsClockSync && Effected,',
     '''            Effected = IsClockSync && Effected,
            ReplayTargetLogId = Kind == TimelineCueKind.Action ? ReplayTargetLogId : 0,
            ReplayTargetName = Kind == TimelineCueKind.Action ? ReplayTargetName : string.Empty,
            ReplayTargetKind = Kind == TimelineCueKind.Action ? ReplayTargetKind : "default",'''),
])

patch("Oracle/Services/FFLogs/FFLogsModels.cs", [
    ('    public string Server { get; init; } = string.Empty;',
     '    public string Server { get; init; } = string.Empty;\n    public string Type { get; init; } = string.Empty;'),
    ('    public IReadOnlyList<FFLogsActorInfo> Players { get; init; } = [];',
     '    public IReadOnlyList<FFLogsActorInfo> Players { get; init; } = [];\n    public IReadOnlyList<FFLogsActorInfo> Actors { get; init; } = [];'),
])

patch("Oracle/Services/FFLogs/FFLogsClient.cs", [
    ('actors(type: "Player") {', 'actors {\n                      type'),
    ('                    Server = node["server"]?.GetValue<string>() ?? string.Empty,',
     '                    Server = node["server"]?.GetValue<string>() ?? string.Empty,\n                    Type = node["type"]?.GetValue<string>() ?? string.Empty,'),
    ('            Players = players.Where(p => p.Id > 0).ToList(),',
     '''            Players = players.Where(p => p.Id > 0 && string.Equals(p.Type, "Player", StringComparison.OrdinalIgnoreCase)).ToList(),
            Actors = players.Where(p => p.Id > 0).ToList(),'''),
])

patch("Oracle/Services/FFLogs/FFLogsImportService.cs", [
    ('        int sourceId)\n    {\n        var cues = new List<TimelineCue>(casts.Count);',
     '''        int sourceId,
        IReadOnlyList<FFLogsActorInfo>? allActors = null)
    {
        var cues = new List<TimelineCue>(casts.Count);'''),
    ('                ActionId = cast.AbilityGameId,',
     '''                ActionId = cast.AbilityGameId,
                ReplayTargetLogId = cast.TargetId,
                ReplayTargetName = allActors?.FirstOrDefault(a => a.Id == cast.TargetId)?.Name ?? string.Empty,
                ReplayTargetKind = cast.TargetId == 0 ? "default"
                    : cast.TargetId == sourceId ? "self"
                    : players.Any(p => p.Id == cast.TargetId) ? "ally"
                    : allActors?.Any(a => a.Id == cast.TargetId && string.Equals(a.Type, "NPC", StringComparison.OrdinalIgnoreCase)) == true ? "enemy"
                    : "unknown",'''),
])

patch("Oracle/UI/FFLogsImportPanel.cs", [
    ('    private bool _importEnemyHitMemos;',
     '    private bool _importEnemyHitMemos;\n    private bool _importReplayAll = true;'),
    ('        DrawImportOptions();\n        DrawAutoLoadSection();',
     '''        DrawImportOptions();
        ImGui.Checkbox("Replay: import ALL player casts (GCD + oGCD)", ref _importReplayAll);
        DrawAutoLoadSection();'''),
    ('        var canCreate = ImportTimelineUi.CanCreate(',
     '        var canCreate = _importReplayAll || ImportTimelineUi.CanCreate('),
    ('        var allowed = C.GetFFLogsImportActionIds(classJobId);',
     '        var allowed = C.GetFFLogsImportActionIds(classJobId);\n        var replayAll = _importReplayAll;'),
    ('        if (allowed.Count == 0\n            && !_importEnemyHitMemos',
     '        if (allowed.Count == 0\n            && !replayAll\n            && !_importEnemyHitMemos'),
    ('            var castsTask = allowed.Count == 0',
     '            var castsTask = allowed.Count == 0 && !replayAll'),
    ('                 allowed,\n                 code));',
     '                 allowed,\n                 code,\n                 replayAll));'),
    ('        HashSet<uint> allowed,\n        string code)\n    {',
     '        HashSet<uint> allowed,\n        string code,\n        bool replayAll)\n    {'),
    ('FFLogsImportService.BuildAllCues(fight, casts, players, player.Id);',
     'FFLogsImportService.BuildAllCues(fight, casts, players, player.Id, _meta?.Actors);'),
    ('            var allCues = allowed.Count == 0',
     '            var allCues = allowed.Count == 0 && !replayAll'),
    ('            var actionCues = allCues\n                .Where(cue => allowed.Contains(cue.ActionId))',
     '            var actionCues = allCues\n                .Where(cue => replayAll || allowed.Contains(cue.ActionId))'),
    ('            if (document.ClassJobId == 0)',
     '            document.ReplayEnabled = replayAll;\n            // Multiple profiles in the same job and duty must not collide in Auto Load.\n            if (replayAll) document.AutoLoadEnabled = false;\n            if (document.ClassJobId == 0)'),
])

patch("Oracle/Services/TimelineStore.cs", [
    ('            Cues = source.Cues.Select(c => c.CopyForDocument()).ToList(),',
     '''            Cues = source.Cues.Select(c => c.CopyForDocument()).ToList(),
            ReplayEnabled = source.ReplayEnabled,
            ReplayExcludedActionIds = source.ReplayExcludedActionIds.ToList(),
            ReplayIndependentActionIds = source.ReplayIndependentActionIds.ToList(),'''),
])

patch("Oracle/Services/PluginServices.cs", [
    ('    internal static IObjectTable ObjectTable { get; private set; } = null!;',
     '    internal static IObjectTable ObjectTable { get; private set; } = null!;\n    internal static ITargetManager TargetManager { get; private set; } = null!;'),
    ('        IObjectTable objectTable,\n        IDataManager dataManager,',
     '        IObjectTable objectTable,\n        ITargetManager targetManager,\n        IDataManager dataManager,'),
    ('        ObjectTable = objectTable;',
     '        ObjectTable = objectTable;\n        TargetManager = targetManager;'),
    ('        ObjectTable = null!;',
     '        ObjectTable = null!;\n        TargetManager = null!;'),
])

patch("Oracle/Plugin.cs", [
    ('    private readonly TimelineEngine _engine;',
     '    private readonly TimelineEngine _engine;\n    private readonly LogMimicService _replay;'),
    ('        IObjectTable objectTable,\n        IDataManager dataManager,',
     '        IObjectTable objectTable,\n        ITargetManager targetManager,\n        IDataManager dataManager,', 2),
    ('            objectTable,\n            dataManager,',
     '            objectTable,\n            targetManager,\n            dataManager,', 2),
    ('        _actionEffectReceive.Subscribe();',
     '        _replay = new LogMimicService(_engine, timelineStore);\n        _actionEffectReceive.Subscribe();'),
    ('        _windowSystem.AddWindow(_overlayWindow);',
     '        _windowSystem.AddWindow(_overlayWindow);\n        _windowSystem.AddWindow(new LogMimicStatusWindow(_replay));'),
    ('            case "unload":',
     '''            case "replay":
                _replay.Command(parts.Skip(1).ToArray());
                break;
            case "unload":'''),
    ('        _engine.Update();\n        _autoRecord.Update();',
     '        _engine.Update();\n        _replay.Update();\n        _autoRecord.Update();'),
    ('        _autoRecord.Dispose();',
     '        _replay.Dispose();\n        _autoRecord.Dispose();'),
])

src = source / "Oracle" / "Services" / "LogMimicService.cs"
dst = root / "Oracle" / "Services" / "LogMimicService.cs"
if dst.exists():
    raise SystemExit(f"STOP: {dst} already exists, refusing overwrite")
dst.write_bytes(src.read_bytes())
print("ADDED", dst)
overlay_src = source / "Oracle" / "Services" / "LogMimicStatusWindow.cs"
overlay_dst = root / "Oracle" / "Services" / "LogMimicStatusWindow.cs"
if overlay_dst.exists(): raise SystemExit(f"STOP: {overlay_dst} exists")
overlay_dst.write_bytes(overlay_src.read_bytes())
print("ADDED", overlay_dst)
print("Patch complete. Compile and review before any in-game use.")
