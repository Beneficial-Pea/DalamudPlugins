using System.Collections.Concurrent;
using Dalamud.Game.ClientState.Objects.Enums;
using Dalamud.Game.ClientState.Objects.Types;
using FFXIVClientStructs.FFXIV.Client.Game;
using Oracle.Models;

namespace Oracle.Services;

// LogMimic experimental extension. Executes only manually enabled replay timelines.
// Does not control movement; a missing/ambiguous target blocks rather than guessing.
internal sealed unsafe class LogMimicService : IDisposable
{
    private readonly TimelineEngine _engine;
    private readonly TimelineStore _store;
    private readonly ConcurrentQueue<uint> _received = new();
    private readonly Dictionary<int, ulong> _boundTargets = new();
    private TimelineDocument? _doc;
    private List<TimelineCue> _main = [];
    private List<TimelineCue> _independent = [];
    private HashSet<string> _independentDone = [];
    private int _mainIndex;
    private string? _pendingMainId;
    private long _pendingMainSince;
    private string? _pendingIndependentId;
    private long _pendingIndependentSince;
    private long _lastAttempt;
    private bool _suspended = true;
    private string _state = "Stopped";

    public LogMimicService(TimelineEngine engine, TimelineStore store)
    {
        _engine = engine;
        _store = store;
        _engine.ActionUse.ActionUsed += OnActionUsed;
    }

    public void Dispose() => _engine.ActionUse.ActionUsed -= OnActionUsed;
    public string State => _state;
    public bool HasReplayDocument => _doc != null;
    public bool Suspended => _suspended;

    private void OnActionUsed(uint actionId, uint targetJobId) => _received.Enqueue(actionId);

    public void Update()
    {
        // Preview must NEVER issue game actions.
        var active = _engine.ActiveDocument;
        if (!_engine.IsRunning || _engine.IsPreview || active is not { ReplayEnabled: true })
        {
            if (_doc != null) Reset();
            _state = "No active replay fight";
            return;
        }
        // Never attempt another job's actions after manually loading a different preset.
        var currentJobId = PluginServices.ObjectTable.LocalPlayer?.ClassJob.RowId ?? 0;
        if (active.ClassJobId == 0 || active.ClassJobId != currentJobId)
        {
            if (_doc != null) Reset();
            _state = $"Job mismatch: timeline job {active.ClassJobId}, current job {currentJobId}";
            return;
        }
        if (!ReferenceEquals(_doc, active)) Begin(active);
        if (_suspended)
        {
            while (_received.TryDequeue(out _)) { }
            _state = "Paused — /oracle replay on";
            return;
        }
        DrainConfirmations();

        var elapsed = _engine.ElapsedSeconds;
        var now = Environment.TickCount64;
        // One attempt at most per 130ms across both lanes: avoid duplicate queue requests.
        if (now - _lastAttempt < 130) return;
        // A queued action may confirm late, especially during long casts.
        if (_pendingMainId != null && now - _pendingMainSince > 2600) _pendingMainId = null;
        if (_pendingIndependentId != null && now - _pendingIndependentSince > 2600) _pendingIndependentId = null;

        // Independent mitigation lane does not wait for the blocked DPS lane.
        foreach (var cue in _independent)
        {
            if (_independentDone.Contains(cue.Id)) continue;
            if (elapsed < cue.TimeOffsetSec) break;
            if (elapsed > cue.TimeOffsetSec + 5f)
            {
                _independentDone.Add(cue.Id); // Do not fire an ancient mitigation after its mechanic.
                continue;
            }
            if (_pendingIndependentId != null) break;
            if (Attempt(cue, now, independent: true)) return;
            // If unavailable (cooldown/range/target) check main without stalling it.
        }

        if (_mainIndex >= _main.Count)
        {
            _state = "Replay finished";
            return;
        }
        var next = _main[_mainIndex];
        if (elapsed < next.TimeOffsetSec)
        {
            _state = $"Waiting {next.TimeOffsetSec - elapsed:0.0}s: {ActionLookup.GetName(next.ActionId)}";
            return;
        }
        if (_pendingMainId == next.Id)
        {
            _state = $"Awaiting confirmation: {ActionLookup.GetName(next.ActionId)}";
            return;
        }
        Attempt(next, now, independent: false);
    }

    private void Begin(TimelineDocument doc)
    {
        Reset();
        _doc = doc;
        var excluded = doc.ReplayExcludedActionIds.ToHashSet();
        var detached = doc.ReplayIndependentActionIds.ToHashSet();
        var ordered = doc.Cues.Where(c => c.Kind == TimelineCueKind.Action && c.ActionId != 0)
            .OrderBy(c => c.TimeOffsetSec).ToList();
        _main = ordered.Where(c => !excluded.Contains(c.ActionId) && !detached.Contains(c.ActionId)).ToList();
        _independent = ordered.Where(c => !excluded.Contains(c.ActionId) && detached.Contains(c.ActionId)).ToList();
        // Explicit opt-in on each fight. No automatic skill execution on startup.
        _suspended = true;
        _state = $"Loaded {_main.Count} DPS + {_independent.Count} independent actions. /oracle replay on";
    }

    private void Reset()
    {
        _doc = null;
        _main = [];
        _independent = [];
        _independentDone.Clear();
        _boundTargets.Clear();
        _mainIndex = 0;
        _pendingMainId = null;
        _pendingIndependentId = null;
        _suspended = true;
        while (_received.TryDequeue(out _)) { }
    }

    private void DrainConfirmations()
    {
        while (_received.TryDequeue(out var used))
        {
            if (_pendingIndependentId != null)
            {
                var pending = _independent.FirstOrDefault(c => c.Id == _pendingIndependentId);
                if (pending != null && Matches(pending.ActionId, used))
                {
                    _independentDone.Add(pending.Id);
                    _pendingIndependentId = null;
                    continue;
                }
            }
            if (_mainIndex < _main.Count && Matches(_main[_mainIndex].ActionId, used))
            {
                _mainIndex++;
                _pendingMainId = null;
            }
        }
    }

    private static bool Matches(uint expected, uint used)
    {
        if (expected == used) return true;
        var manager = ActionManager.Instance();
        return manager != null && manager->GetAdjustedActionId(expected) == used;
    }

    private bool Attempt(TimelineCue cue, long now, bool independent)
    {
        var target = ResolveTarget(cue, out var reason);
        if (reason != null)
        {
            _state = $"Waiting for target {cue.ReplayTargetLogId} ({cue.ReplayTargetName}): {reason}";
            return false;
        }
        var manager = ActionManager.Instance();
        if (manager == null) return false;
        var actionId = manager->GetAdjustedActionId(cue.ActionId);
        if (actionId == 0) actionId = cue.ActionId;
        // Status != 0 covers cooldown, range, animation lock and other invalid states.
        // Strict DPS lane stays on this exact cue; it never advances by elapsed time.
        if (target != null && (cue.ReplayTargetKind == "enemy" || cue.ReplayTargetKind == "ally"))
            PluginServices.TargetManager.Target = target;
        var targetId = target?.GameObjectId ?? PluginServices.TargetManager.Target?.GameObjectId ?? 0xE0000000UL;
        if (manager->GetActionStatus(ActionType.Action, actionId, targetId) != 0)
        {
            _state = $"Retrying: {ActionLookup.GetName(cue.ActionId)} ({(independent ? "independent" : "strict")})";
            return false;
        }
        _lastAttempt = now;
        var sent = manager->UseAction(ActionType.Action, actionId, targetId);
        if (sent)
        {
            if (independent)
            {
                _pendingIndependentId = cue.Id;
                _pendingIndependentSince = now;
            }
            else
            {
                _pendingMainId = cue.Id;
                _pendingMainSince = now;
            }
        }
        _state = sent ? $"Sent: {ActionLookup.GetName(cue.ActionId)}" : $"Retry: {ActionLookup.GetName(cue.ActionId)}";
        return sent;
    }

    private IGameObject? ResolveTarget(TimelineCue cue, out string? reason)
    {
        reason = null;
        if (cue.ReplayTargetKind == "self")
            return PluginServices.ObjectTable.LocalPlayer;
        if (cue.ReplayTargetKind == "default" || cue.ReplayTargetLogId == 0)
            return null;
        if (_boundTargets.TryGetValue(cue.ReplayTargetLogId, out var gameObjectId))
        {
            var objectRef = PluginServices.ObjectTable.SearchById(gameObjectId);
            if (objectRef is { IsDead: false, IsTargetable: true }) return objectRef;
            _boundTargets.Remove(cue.ReplayTargetLogId);
        }
        if (cue.ReplayTargetKind == "unknown")
        {
            reason = "unclassified FFLogs actor, manual bind required";
            return null;
        }
        if (string.IsNullOrWhiteSpace(cue.ReplayTargetName))
        {
            reason = "missing target name; manual bind required";
            return null;
        }
        var candidates = PluginServices.ObjectTable
            .Where(o => o is { IsDead: false, IsTargetable: true }
                && (cue.ReplayTargetKind == "enemy" ? o.ObjectKind == ObjectKind.BattleNpc
                    : o.ObjectKind == ObjectKind.Pc)
                && string.Equals(o.Name.TextValue, cue.ReplayTargetName, StringComparison.OrdinalIgnoreCase))
            .ToArray();
        if (candidates.Length == 1)
        {
            _boundTargets[cue.ReplayTargetLogId] = candidates[0]!.GameObjectId;
            return candidates[0];
        }
        reason = candidates.Length == 0 ? "not spawned / localized name mismatch" : "multiple matches; bind manually";
        return null;
    }

    public void Command(string[] args)
    {
        var part = args.Length == 0 ? "status" : args[0].ToLowerInvariant();
        var doc = _engine.ActiveDocument ?? _store.ActiveDocument;
        switch (part)
        {
            case "on":
                if (_doc == null || !_engine.IsRunning || _engine.IsPreview)
                {
                    Message("Load a replay document and start a real fight first.");
                    break;
                }
                _suspended = false;
                Message("ON — strict replay enabled");
                break;
            case "off":
                _suspended = true;
                Message("OFF — replay paused");
                break;
            case "status":
                Message($"{_state} | main={_mainIndex}/{_main.Count}, independent={_independentDone.Count}/{_independent.Count}");
                break;
            case "list":
            {
                var candidates = _store.Documents.Where(d => d.ReplayEnabled)
                    .OrderBy(d => d.ClassJobId).ThenBy(d => d.Name).ToList();
                if (candidates.Count == 0) { Message("No imported replay timelines."); break; }
                Message($"Saved replay profiles: {candidates.Count} (any job, any FFLogs report)");
                foreach (var profile in candidates.Take(60))
                    Message($"[{JobActionCatalog.GetJobLabel(profile.ClassJobId)}] {profile.Name}");
                if (candidates.Count > 60) Message("Showing first 60 profiles only.");
                break;
            }
            case "load":
            {
                if (_engine.IsRunning) { Message("Load a different profile before pull."); break; }
                var token = string.Join(' ', args.Skip(1)).Trim();
                if (string.IsNullOrEmpty(token)) { Message("Usage: /oracle replay load <timeline name>"); break; }
                var profile = _store.FindByLoadToken(token);
                if (profile == null || !profile.ReplayEnabled)
                {
                    Message($"Replay timeline not found: {token}");
                    break;
                }
                var jobId = PluginServices.ObjectTable.LocalPlayer?.ClassJob.RowId ?? 0;
                if (profile.ClassJobId == 0 || jobId != profile.ClassJobId)
                {
                    Message($"Profile is for job {profile.ClassJobId}; change to the matching job before pull.");
                    break;
                }
                _engine.ManualLoad(profile);
                Message($"Loaded [{JobActionCatalog.GetJobLabel(profile.ClassJobId)}] {profile.Name}");
                break;
            }
            case "skip":
                if (_mainIndex < _main.Count)
                {
                    Message($"Skipped {_main[_mainIndex].ActionId} (manual only)");
                    _mainIndex++;
                    _pendingMainId = null;
                }
                break;
            case "targets":
                if (doc == null) break;
                foreach (var t in doc.Cues.Where(c => c.ReplayTargetLogId != 0)
                    .GroupBy(c => c.ReplayTargetLogId)
                    .Select(g => g.First()).Take(30))
                    Message($"FFLogs {t.ReplayTargetLogId}: {t.ReplayTargetName} [{t.ReplayTargetKind}]");
                break;
            case "bind":
                if (args.Length < 2 || !int.TryParse(args[1], out var logId)) break;
                var selected = PluginServices.TargetManager.Target;
                if (selected == null) { Message("Target the intended monster first."); break; }
                _boundTargets[logId] = selected.GameObjectId;
                Message($"Bound FFLogs {logId} to {selected.Name.TextValue}");
                break;
            case "exclude":
            case "independent":
                if (doc == null || args.Length < 2 || !uint.TryParse(args[1], out var id)) break;
                var list = part == "exclude" ? doc.ReplayExcludedActionIds : doc.ReplayIndependentActionIds;
                if (list.Contains(id)) list.Remove(id);
                else list.Add(id);
                _store.SaveDocument(doc);
                Message($"Updated {part} {id}. Takes effect on next pull.");
                break;
            default:
                Message("Commands: list, load <name>, on, off, status, skip, targets, bind <logActorId>, exclude <actionId>, independent <actionId>");
                break;
        }
    }

    private static void Message(string message) => PluginServices.ChatGui.Print($"[LogMimic] {message}");
}
