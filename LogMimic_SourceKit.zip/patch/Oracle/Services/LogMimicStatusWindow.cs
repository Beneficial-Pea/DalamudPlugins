using Dalamud.Interface.Windowing;

namespace Oracle.Services;

/// <summary>Compact replay status placed just above Oracle's native cue overlay.</summary>
internal sealed class LogMimicStatusWindow : Window
{
    private readonly LogMimicService _replay;
    public LogMimicStatusWindow(LogMimicService replay)
        : base("LogMimic Status##oracleReplayStatus", ImGuiWindowFlags.NoDecoration |
            ImGuiWindowFlags.NoSavedSettings | ImGuiWindowFlags.AlwaysAutoResize |
            ImGuiWindowFlags.NoFocusOnAppearing)
    {
        _replay = replay;
        IsOpen = true;
        RespectCloseHotkey = false;
        DisableWindowSounds = true;
    }
    public override bool DrawConditions() => C.ShowOverlay && _replay.HasReplayDocument;
    public override void PreDraw() => ImGui.SetNextWindowPos(
        new Vector2(C.OverlayPosX, MathF.Max(0, C.OverlayPosY - 30)), ImGuiCond.Always);
    public override void Draw() => ImGui.TextUnformatted("LogMimic | " + _replay.State);
}
