LogMimic — 전투 직업 전체 대응, 실험적 Oracle v1.3.4 소스 패치

기준 FFLogs: https://www.fflogs.com/reports/tQDfGpjNWq2JcyRk?fight=4&type=damage-done
전투: 4 / 플레이어: 원본 Oracle의 FFLogs 가져오기 화면에서 선택
이 링크는 샘플이며 플러그인에 고정되어 있지 않습니다. 다른 FFLogs 링크와 다른 직업도 불러올 수 있습니다.

중요: LogMimic은 현재 독립 Dalamud 플러그인이 아니라 Oracle의 소스 패치입니다. Dalamud 설치 목록에는 여전히 Oracle로 표시됩니다.
이 배포본은 테스트가 끝난 DLL이 아닙니다. Oracle 원본에 적용하는 실험적 소스 패치입니다.
Dalamud 게임 내 컴파일/실행 테스트 미완료. 자동화 플러그인 사용에는 계정 제재 위험이 있습니다.

설치(개발자용)
1. https://github.com/exatrines/Oracle 의 1.3.4 버전 소스를 git clone --recurse-submodules 로 내려받습니다.
2. patch_oracle.py 와 Oracle/Services/LogMimicService.cs 를 Oracle 프로젝트 경로 기준으로 가져옵니다.
3. python patch_oracle.py /path/to/Oracle-repo 를 실행합니다.
4. Windows + .NET 10 + Dalamud dev reference를 갖춘 PC에서 dotnet build Oracle.sln -c Release -p:Platform=x64 로 빌드합니다.
5. Dalamud 개발 플러그인 경로를 지정해 로드합니다. 기존 Oracle과 동시에 로드하지 마세요.
6. Oracle FFLogs 설정에 Client ID/Secret을 등록하고 링크를 가져옵니다. 해당 전투와 플레이어를 선택합니다.
7. 'Replay: import ALL casts' 옵션을 켜고 타임라인을 생성합니다. 자동 불러오기는 꺼진 상태로 저장됩니다.
   같은 임무·같은 직업에 여러 로그가 저장되면 자동 선택이 중복될 수 있어 수동 선택이 기본값입니다.
   몽크·사무라이 등 다른 직업도 각각 FFLogs 보고서를 입력하고 플레이어를 선택하여 따로 저장합니다.
   현재 보고서에 없는 직업의 스킬 기록은 생성할 수 없으며, 그 직업이 등장하는 다른 로그가 필요합니다.
7-1. 게임에서 해당 직업으로 변경한 뒤 /oracle replay list로 프리셋 목록을 확인하고,
     /oracle replay load <타임라인 이름> 으로 이번 전투에서 사용할 프리셋을 선택합니다.
8. 임무 진입 후 /oracle replay targets 로 타깃 매핑을 확인하고, 필요 시 몹을 선택한 뒤 /oracle replay bind <FFLogs actor ID> 입력.
9. 실전에서 /oracle replay on 을 직접 입력해야 실행됩니다. /oracle replay off 로 중단.

명령어
/oracle replay list : 모든 저장된 직업별/로그별 프리셋 나열
/oracle replay load <타임라인 이름> : 현재 직업용 프리셋 불러오기 (풀링 전)
/oracle replay status : 실행 상태, 진행 수
/oracle replay on/off : 실행 허용/일시중지
/oracle replay skip : 순서가 막혔을 때 현재 스킬 수동 건너뛰기
/oracle replay targets : FFLogs 원본 대상 ID와 이름 목록
/oracle replay bind 123 : 현재 선택한 게임 내 몹을 FFLogs 대상 123과 매핑
/oracle replay exclude 7561 : 해당 Action ID 제외 토글 (예: 신속마; 실제 직업별 확인 필요)
/oracle replay independent 7549 : 별도 타이머에 해당 Action ID 등록 토글 (예: 견제)

직업별 반복 사용 예시
- 동일한 Dalamud 플러그인 하나로 몽크 / 사무라이 / 다른 전투 직업을 모두 처리합니다. 직업별 DLL은 필요 없습니다.
- 몽크: 몽크 포함 FFLogs 링크 → 몽크 플레이어 선택 → 전체 Cast 가져오기 → 프리셋 저장
- 사무라이: 사무라이 포함 FFLogs 링크 → 사무라이 플레이어 선택 → 전체 Cast 가져오기 → 별도 프리셋 저장
- 다른 직업: 링크/플레이어만 바꿔 동일하게 반복. 서로 다른 직업·같은 직업의 다른 보고서 모두 저장할 수 있습니다.
- /oracle replay exclude 및 independent 설정은 각 타임라인 파일에 따로 보관됩니다.
- 직업을 잘못 선택해 불러온 프리셋의 자동 전투 실행은 차단하도록 검사합니다.

설계 및 한계
- 자동 발동은 타임라인의 모든 GCD/oGCD를 시간순 메인 큐로 실행하되, 성공을 확인하기 전에는 다음 스킬로 이동하지 않습니다.
- 견제 등 독립 행동은 별도 큐에서 원래 예정 시각부터 5초간 시도 후 만료합니다(기계적 안전 장치).
- FFLogs 로그 대상 ID와 게임 내 대상의 GameObjectId는 다릅니다. 같은 이름이 2마리이면 자동으로 추측하지 않고 bind 명령이 필요합니다.
- 원본 Oracle 오버레이는 그대로 유지합니다. 현재 스킬 상태는 /oracle replay status로 확인합니다.
- 이동, 방향 전환, AoE 지면 지정, 보스 페이즈 재동기화, GCD 클리핑 최소화 최적화는 미구현입니다.
- RSR/BossMod의 별도 자동 스킬 실행을 켜 두면 충돌합니다. 이 실험용 스킬 실행기와 동시에 실행하지 마세요.
- 일부 FFLogs cast event는 target ID가 0이거나 불분명합니다. 이런 경우에는 현재 대상 기준으로 실행될 수 있어 대상 완전 재현을 보장하지 않습니다.
- FFLogs 직접 데이터 조회는 API 인증이 필요하므로 이 실행 환경에서 보고서 4번의 실제 스킬·플레이어 목록을 검증하지 못했습니다.
- 현재 스킬 실행 재시도 시간 제한은 2.6초(응답 대기), 최소 스킬 시도 간격은 130ms입니다. 현장 검증 시 조정해야 합니다.
- 소스가 AGPL-3.0-or-later인 Oracle을 기반으로 하므로 배포 시 원본 라이선스 의무를 따르세요.
