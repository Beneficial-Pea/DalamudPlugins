#!/usr/bin/env python3
"""Patch upstream Oracle 1.3.4 and make a separately named LogMimic plugin.

This intentionally does NOT claim a successful build; the release CI must compile.
"""
from __future__ import annotations
import argparse
import json
import subprocess
import sys
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('source', type=Path, help='Oracle source checkout root')
ap.add_argument('--repository', default='Beneficial-Pea/DalamudPlugins')
ap.add_argument('--version', default='0.1.0.0')
args = ap.parse_args()
root = args.source.resolve()
repo_root = Path(__file__).resolve().parent
if not (root/'Oracle'/'Oracle.csproj').exists():
    raise SystemExit('Missing source checkout: Oracle/Oracle.csproj')

subprocess.run([sys.executable, str(repo_root/'patch'/'patch_oracle.py'), str(root)], check=True)

plugin = root/'Oracle'/'Plugin.cs'
s = plugin.read_text(encoding='utf-8')
for old, new in [
    ('public const string Name = "Oracle";', 'public const string Name = "LogMimic";'),
    ('private const string CommandName = "/oracle";', 'private const string CommandName = "/logmimic";'),
]:
    if s.count(old) != 1:
        raise RuntimeError(f'Unexpected upstream source anchor {old}')
    s = s.replace(old, new)
plugin.write_text(s, encoding='utf-8')

# Plugin type remains namespace Oracle.Plugin; distinct AssemblyName/InternalName prevents collision.
proj = root/'Oracle'/'Oracle.csproj'
s = proj.read_text(encoding='utf-8')
for old, new in [
    ('<AssemblyName>Oracle</AssemblyName>', '<AssemblyName>LogMimic</AssemblyName>'),
    ('<None Update="Oracle.json">', '<None Update="LogMimic.json">'),
]:
    if s.count(old) != 1: raise RuntimeError(f'Unexpected csproj anchor: {old}')
    s=s.replace(old,new)
proj.write_text(s,encoding='utf-8')

svc = root/'Oracle'/'Services'/'LogMimicService.cs'
s=svc.read_text(encoding='utf-8').replace('/oracle replay', '/logmimic replay')
svc.write_text(s, encoding='utf-8')

# User-visible strings may still mention Oracle for the inherited timeline editor.
# The original Oracle plugin stays a separate installation.
base=json.loads((root/'Oracle'/'Oracle.json').read_text(encoding='utf-8'))
base.update({
    'Author': 'Beneficial-Pea',
    'Name': 'LogMimic',
    'InternalName': 'LogMimic',
    'AssemblyVersion': args.version,
    'Punchline': 'Replay FFLogs cast timelines with target-aware automation.',
    'Description': ('Experimental FFLogs GCD/oGCD replay based on Oracle. '
                    'Manual enable, strict main queue, independent mitigation queue, and target mapping. '
                    'Not verified in actual combat.'),
    'RepoUrl': f'https://github.com/{args.repository}',
    'IconUrl': f'https://raw.githubusercontent.com/{args.repository}/main/plugins/LogMimic/icon.png',
    'DalamudApiLevel': 15,
    'ApplicableVersion': 'any',
    'ImageUrls': [],
})
for key in ('DownloadLinkInstall','DownloadLinkUpdate','DownloadLinkTesting'):
    base.pop(key, None)
(root/'Oracle'/'LogMimic.json').write_text(json.dumps(base,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Standalone name:',base['InternalName'],'repo:',args.repository)
